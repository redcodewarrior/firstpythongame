Images used for game to work

