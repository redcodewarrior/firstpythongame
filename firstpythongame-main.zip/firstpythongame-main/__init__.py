"""
__init__py para iniciar game
"""

# importo la Clase Game desde archivo game
# el archivo lleva un "." antes si esta en otro directorio
from game import Game 

