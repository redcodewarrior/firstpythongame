Sounds of grabbing coins and collision with wall/enemy

