# firstpythongame
First Python Game Using pygame

Use main.py to start game

Edit config.py to change FPS, speed, colors and more

